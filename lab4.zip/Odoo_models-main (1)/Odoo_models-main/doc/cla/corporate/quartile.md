Hong Kong, 2017-09-18

Quartile Limited agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Yoshi Tashiro tashiro@quartile.co https://github.com/yostashiro

List of contributors:

Yoshi Tashiro tashiro@quartile.co https://github.com/yostashiro
Ryoko Tsuda ryoko@quartile.co https://github.com/Ryoko04
Tatsuki Kanda kanda@quartile.co https://github.com/kanda999
Aung Ko Ko Lin lin@quartile.co https://github.com/AungKoKoLin1997
Toshikimi Shigenobu nobu@quartile.co https://github.com/nobuQuartile
