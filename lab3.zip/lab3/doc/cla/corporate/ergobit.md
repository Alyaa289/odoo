Senegal, 2022-11-24

ERGOBIT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Bassirou Ndaw b.ndaw@ergobit.org https://github.com/bassn

List of contributors:

* Bassirou Ndaw b.ndaw@ergobit.org https://github.com/bassn
* Oliver Meyer o.meyer@ergobit.org https://github.com/oli-meyer
* 
