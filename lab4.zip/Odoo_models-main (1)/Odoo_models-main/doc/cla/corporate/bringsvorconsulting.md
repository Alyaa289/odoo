Norway, 2015-04-13

Bringsvor Consulting AS agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Torvald Baade Bringsvor bringsvor@bringsvor.com https://github.com/bringsvor

List of contributors:

Torvald Baade Bringsvor bringsvor@bringsvor.com, torvald@bringsvor.com https://github.com/bringsvor
