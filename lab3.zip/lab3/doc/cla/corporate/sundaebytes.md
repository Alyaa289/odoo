Trinidad and Tobago, 2023-10-03

SundaeBytes agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Kwasi Edwards kwasiedwards@gmail.com   https://github.com/kwasi-dev

List of contributors:
Kwasi Edwards kwasiedwards@gmail.com   https://github.com/kwasi-dev
Kwasi Edwards kwasi.edwards@sundaebytes.com https://github.com/sundaebytes
Kwasi Edwards kwasi_edwards2@hotmail.com https://github.com/kwasi-dev
