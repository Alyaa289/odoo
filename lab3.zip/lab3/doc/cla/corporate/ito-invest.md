Luxembourg, February 28th, 2023

Ito Invest sarl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jérôme Sonnet jerome.sonnet@ito-invest.lu https://github.com/ito-invest-lu

List of contributors:

Jérôme Sonnet jerome.sonnet@ito-invest.lu https://github.com/ito-invest-lu
