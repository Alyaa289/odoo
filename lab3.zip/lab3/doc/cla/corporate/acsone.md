Belgium, 2015-02-11

ACSONE SA/NV agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Stéphane Bidoul stephane.bidoul@acsone.eu https://github.com/sbidoul

List of contributors:

Adrien Peiffer adrien.peiffer@acsone.eu https://github.com/adrienpeiffer
Anthony Muschang anthony.muschang@acsone.eu https://github.com/anthony-muschang
Cédric Pigeon cedric.pigeon@acsone.eu https://github.com/Cedric-Pigeon
Christelle De Coninck christelle.deconinck@acsone.eu https://github.com/chrisdec
Jonathan Nemry jonathan.nemry@acsone.eu https://github.com/JonathanNEMRY
Denis Roussel denis.roussel@acsone.eu https://github.com/rousseldenis
Laetia Gangloff laetitia.gangloff@acsone.eu https://github.com/laetitia-gangloff
Laurent Mignon laurent.mignon@acsone.eu https://github.com/lmignon
Olivier Laurent olivier.laurent@acsone.eu https://github.com/Olivier-LAURENT
Philippe Schmidt philippe.schmidt@acsone.eu https://github.com/phschmidt
Stéphane Bidoul stephane.bidoul@acsone.eu https://github.com/sbidoul
Thomas Binsfeld thomas.binsfeld@acsone.eu https://github.com/ThomasBinsfeld
Benjamin Willig benjamin.willig@acsone.eu https://github.com/benwillig
François Honoré francois.honore@acsone.eu https://github.com/acsonefho
Denis Robinet denis.robinet@acsone.eu https://github.com/RobinetDenisAcsone
Benoit Aimont benoit.aimont@acsone.eu https://github.com/baimont
Bejaoui Souheil souheil.bejaoui@acsone.eu https://github.com/sbejaoui
Nans Lefebvre nans.lefebvre@acsone.eu https://github.com/len-foss
Régis Pirard regis.pirard@acsone.eu https://github.com/regispirard
Xavier Bouquiaux xavier.bouquiaux@acsone.eu https://github.com/xavier-bouquiaux
Maxime Franco maxime.franco@acsone.eu https://github.com/FrancoMaxime
Marie Lejeune marie.lejeune@acsone.eu https://github.com/marielejeune
Justine Doutreloux justine.doutreloux@acsone.eu https://github.com/jdoutreloux
Laurent Stukkens laurent.stukkens@acsone.eu https://github.com/it-ideas
