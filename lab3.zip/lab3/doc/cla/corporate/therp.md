Netherlands, 2015-03-09

Updated:
    2016-05-27
    2017-06-27
    2020-10-08
    2021-03-02
    2025-03-06

Therp BV agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

We declare that we are authorized and able to make this agreement and sign
this declaration.

Signed,

*  Ronald Portier ronald@therp.nl https://github.com/nl66278

List of contributors:

*  Giovanni Capalbo giovanni@therp.nl https://github.com/gfcapalbo
*  Holger Brunn hbrunn@therp.nl https://github.com/hbrunn (up to 2020-05-31)
*  Lara Freeke lfreeke@therp.nl https://github.com/lfreeke
*  Ronald Portier ronald@therp.nl https://github.com/nl66278
*  George Daramouskas gdaramouskas@therp.nl https://github.com/daramousk
*  Nikos Tsirintanis ntsirintanis@therp.nl https://github.com/ntsirintanis
*  Jan Verbeek jverbeek@therp.nl https://github.com/janverb
*  Danny de Jong ddejong@therp.nl https://github.com/ddejong-therp

