Sweden, 2019-10-07

XCLUDE AB agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Daniel Stenlöv daniel.stenlov@xclude.se https://github.com/daniel-stenlov

List of contributors:

Daniel Stenlöv daniel.stenlov@xclude.se https://github.com/daniel-stenlov

