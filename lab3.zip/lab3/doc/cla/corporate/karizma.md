Morocco, 2019-03-21

KARIZMA CONSEIL agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.


Signed,

Saad THAIFA saad.thaifa@gmail.com https://github.com/saadthaifa

List of contributors:

Saad THAIFA saad.thaifa@karizma.ma https://github.com/saadthaifa
Ahmed MOUFID a.moufid@karizma.ma https://github.com/moufidahmed
Reda ROUICHI r.rouichi@karizma.ma https://github.com/r2gtx
Abdelmajid ELHAMDAOUI a.elhamdaoui@karizma.ma https://github.com/elhamdaoui
Ayoub LABIBI a.labibi@karizma.ma https://github.com/labibi
