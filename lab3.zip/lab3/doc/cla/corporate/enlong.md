china, 2022-05-20

Enlong agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Kevin Enlong kevin@enlong.cn https://github.com/kevinenlong

List of contributors:

Kevin Enlong kevin@enlong.cn https://github.com/kevinenlong