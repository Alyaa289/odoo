Belgium, 2016-02-06

be-cloud.be agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jerome Sonnet jerome.sonnet@be-cloud.be https://github.com/be-cloud-js

List of contributors:

Jerome Sonnet jerome.sonnet@be-cloud.be https://github.com/be-cloud-js