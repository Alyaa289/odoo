Canada, 2023-11-01

Whetstone Advisory Group agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Bruce Rochester bruce@whetstoneadvisory.com https://github.com/whetstoneadvisory

List of contributors:

Bruce Rochester bruce@whetstoneadvisory.com https://github.com/whetstoneadvisory
