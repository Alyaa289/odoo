Denmark, 2024-02-20

Asergo aps agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Kasper Fock kasperf@asergo.com https://github.com/kasper-f

List of contributors:

Kasper Fock kasperf@asergo.com https://github.com/kasper-f
