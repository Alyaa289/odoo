France, 31/10/2019

SERENITE 24H24 agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Arnaud Willem arnaud@jaunedemars.fr https://github.com/a-willem

List of contributors:

Arnaud Willem arnaud@jaunedemars.fr https://github.com/a-willem
