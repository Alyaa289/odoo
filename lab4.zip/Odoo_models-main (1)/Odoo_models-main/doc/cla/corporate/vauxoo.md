México, 2015-02-09

Vauxoo agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Moisés López moylop260@vauxoo.com https://github.com/moylop260

List of contributors:

Humberto Arocha hbto@vauxoo.com https://github.com/hbto
Javier Duran javier@vauxoo.com
Moisés López moylop260@vauxoo.com https://github.com/moylop260
Nhomar Hernández nhomar@vauxoo.com https://github.com/nhomar
Sabrina Romero sabrina@vauxoo.com https://github.com/dsabrinarg
Yanina Aular yanina.aular@vauxoo.com https://github.com/yaniaular
Oscar Alcala oszckar@gmail.com.com https://github.com/oscarolar
Oscar Alcala oscar@vauxoo.com https://github.com/oscarolar
Luis Ernesto García Medina ernesto_gm@vauxoo.com https://github.com/ernesto-gm
Julio Serna julio@vauxoo.com https://github.com/JulioSerna
Jorge Angel Naranjo Rogel jorge_nr@vauxoo.com https://github.com/jorgenaranjo
Jose Antonio Morales Ponce jose@vauxoo.com https://github.com/josemoralesp
Tulio Ruiz tulio@vauxoo.com https://github.com/ruiztulio
Luis Torres luis_t@vauxoo.com https://github.com/luistorresm
Gabriela Quilarque gabriela@vauxoo.com https://github.com/gquilarque
Katherine Zaoral kathy@vauxoo.com https://github.com/zaoral
Hugo Adan hugo@vauxoo.com https://github.com/hugho-ad
Alan Guzman aguzman@vauxoo.com https://github.com/alan-guzman
Leonardo Astros leonardo@vauxoo.com https://github.com/Codemaker83
Jose Angel Fentanez Delfin joseangel@vauxoo.com https://github.com/Angelfentanez
Osval Reyes osval@vauxoo.com https://github.com/osvalr
Jose Suniaga josemiguel@vauxoo.com https://github.com/suniagajose
Luis González lgonzalez@vauxoo.com https://github.com/luisg123v
Oriana Maita oriana@vauxoo.com https://github.com/maitaoriana
Gabriela Mogollon gmogollon@vauxoo.com https://github.com/GavyMG
Jesus Zapata jesus@vauxoo.com https://github.com/JesusZapata
Germana Oliveira germana@vauxoo.com https://github.com/goliveirab
Mariano Fernandez mariano@vauxoo.com https://github.com/Batuto
Edgar Rivero edgar@vauxoo.com https://github.com/egrivero
Edilianny Sánchez esanchez@vauxoo.com https://github.com/edy1192
Alexander Olivares alexander@vauxoo.com https://github.com/alxolivares
Jose Manuel Robles josemanuel@vauxoo.com https://github.com/keylor2906
Erick Birbe erick@vauxoo.com https://github.com/ebirbe
Tomas Alvarez tomas@vauxoo.com https://github.com/tomeyro
Carmen Liliana Miranda González carmen@vauxoo.com https://github.com/CarmenMiranda
Arturo Flores arturo@vauxoo.com https://github.com/umiphos
Deivis Laya deivis@vauxoo.com https://github.com/deivislaya
Yennifer Santiago yennifer@vauxoo.com https://github.com/ysantiago
Randall Castro randall@vauxoo.com https://github.com/randall-vx
Alejandro Santillan asantillan@vauxoo.com https://github.com/R4Alex
Williams Estrada williams@vauxoo.com https://github.com/WR-96
Fernanda Hernández fernanda@vauxoo.com https://github.com/fernandahf
Luigys Toro luigys@vauxoo.com https://github.com/desdelinux
Francisco J. Luna fluna@vauxoo.com https://github.com/frahikLV
Andrea Arce andrea@vauxoo.com https://github.com/andreaarce
Francisco Alejandro González Luna aluna@vauxoo.com https://github.com/TheAlekLuna
Juan Benavente jbenavente@vauxoo.com https://github.com/jjbenavaz
Alejandro Garza agarza@vauxoo.com https://github.com/agarzaarvizu
Ulises Rivadeneyra ulises@vauxoo.com https://github.com/UlisesRivadeneyra
Alexis Hernandez alexis@vauxoo.com https://github.com/sebasdrk17
Agustin Payen payen@vauxoo.com https://github.com/payen000
Rodrigo Serrano rodrigosu@vauxoo.com https://github.com/Rodrigosu-Vauxoo
Isaac López isaac@vauxoo.com https://github.com/isaako34
Rolando Duarte rolando@vauxoo.com https://github.com/rolandojduartem
Andy Quijada andy@vauxoo.com https://github.com/ajqn9094
Carlos Carral carlos.c@vauxoo.com https://github.com/carralc
Luis Manuel luis.manuel@vauxoo.com https://github.com/LuisMzz
Alejandro Mellado alejandromm@vauxoo.com https://github.com/alejandromellado
Andrea Geraldo myrna.andrea@vauxoo.com https://github.com/AndreaGeraldo
Andrea Gidalti andreag@vauxoo.com  https://github.com/andreagidaltig
German Loredo german@vauxoo.com https://github.com/xmglord 
Antonio Aguilar antonio@vauxoo.com https://github.com/antonag32
Christihan Laurel laurel@vauxoo.com https://github.com/CLaurelB
Andrea Manenti manenti@vauxoo.com https://github.com/maneandrea
Eduardo Martinez eduardoms@vauxoo.com https://github.com/emtz10
