Italy, 22-04-2021

Digital Domus s.n.c. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Alessandro Fiorino alessandro.fiorino@digitaldomus.it https://github.com/alessandro-fiorino

List of contributors:

Alessandro Fiorino alessandro.fiorino@digitaldomus.it https://github.com/alessandro-fiorino
