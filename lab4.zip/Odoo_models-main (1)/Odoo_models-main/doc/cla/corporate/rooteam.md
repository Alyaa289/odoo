United States of America, 2025-01-28

Rooteam agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Gabriel Grinspan gabriel@rooteam.net https://github.com/gabe-grinspan

List of contributors:

Gabriel Grinspan gabriel@rooteam.net https://github.com/gabe-grinspan
Gabriel Grinspan grinspan.gabriel@gmail.com https://github.com/gabe-grinspan
