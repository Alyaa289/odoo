USA, 2024-11-26

Xcellent Exchange USA LLC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jason Sims jason.sims@xcellentexchange.com https://github.com/JasonMSims

List of contributors:

Jason Sims jason.sims@xcellentexchange.com https://github.com/JasonMSims