Italy, 2020-10-02

Openforce Srls Unipersonale agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Silvio Gregorini silviogregorini@openforce.it https://github.com/SilvioGregorini

List of contributors:

Alessandro Camilli alessandrocamilli@openforce.it https://github.com/alessandrocamilli
Matteo Mircoli matteomircoli@openforce.it https://github.com/matteoopenf
Susanna Ortini susannaortini@openforce.it https://github.com/suassa
Dario Del Zozzo dariodelzozzo@openforce.it https://github.com/ddzopenforce
Patrick Trabocchi patricktrabocchi@openforce.it https://github.com/patrickt-oforce
