France, 2020-06-30

Vittoria Conseil agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Romain Tartière romain@vittoriaconseil.com https://github.com/smortex

List of contributors:

Jérémie Payet jeremie@vittoriaconseil.com https://github.com/jpcweb
Romain Tartière romain@vittoriaconseil.com https://github.com/smortex
