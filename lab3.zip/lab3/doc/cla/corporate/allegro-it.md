Latvia, 2022-07-22

Allegro IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Arnis Putniņš arnis@allegro.lv https://github.com/Allegro-IT

List of contributors:

Arnis Putniņš arnis@allegro.lv https://github.com/Allegro-IT
Santa Ašmane santa@allegro.lv https://github.com/Allegro-IT
