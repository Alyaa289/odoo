Germany, 2023-01-11

cloudition GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Stefan Reisich stefan.reisich@cloudition.de https://github.com/sreisich

List of contributors:

Stefan Reisich stefan.reisich@cloudition.de https://github.com/sreisich
