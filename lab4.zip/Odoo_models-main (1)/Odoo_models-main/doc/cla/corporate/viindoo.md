Vietnam, 2020-06-24

Viindoo Technology Joint Stock Company agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Leo Tran leo.tran@viindoo.com https://github.com/leotranviindoo
Roy Le roy.le@viindoo.com https://github.com/royleviindoo

List of contributors:

David Tran david.tran@tvtmarine.com https://github.com/davidtranhp
Nguyen Viet Phuong nguyenvietphuong1010@gmail.com https://github.com/vietphuong10
La Van Thuat lathuat1997@gmail.com https://github.com/lathuat1997
Trinh Viet Duc duc.trinh@viindoo.com https://github.com/vietduc1989
Le Ngoc Huy ngochuy97hp@gmail.com https://github.com/ngochuy97hp
Tran Ngoc Son transon821996@gmail.com https://github.com/TranNgocSon1996
Pham Hoang Giang phamgiang2510@gmail.com https://github.com/phamgiang2510
Hoang Tien Dung hoangtiendung070797@gmail.com https://github.com/hoangtiendung070797
Bui The Anh anhbtit@gmail.com https://github.com/anhbtit
Dao Van Nam daonamutc@gmail.com https://github.com/daonamutc1
Pham Quang Linh lnkphm@gmail.com https://github.com/lnkphm
Nguyen Hong Quang nguyenquang2796@gmail.com https://github.com/Ngquang
Hoang Dinh Hieu hieu.hoang121199@gmail.com https://github.com/hieu1211
Vu Van Phat aloha050992@gmail.com https://github.com/phatvu4035
Pham Nhu Y ypnwebdev@gmail.com https://github.com/ypn
Ta Quang Thinh taqthinh@gmail.com https://github.com/taqthinh
Pham Thi Ngoc ngoc79225@st.vimaru.edu.vn https://github.com/ngoc3005
Pham Thuy Linh linhpt03690@gmail.com https://github.com/linhpt03690
Phung Van Tuyen phungvantuyen97@gmail.com https://github.com/tuyenphung
Vu Tuan Hung hungvuhunglinh@gmail.com https://github.com/Hung412
Nguyen Dai Duong daiduongnguyen2709@gmail.com https://github.com/duong77476
Quan Trong Hung kasskun198@gmail.com https://github.com/tronghung0398
Tran Truong Son truongson290893@gmail.com https://github.com/SonCrits
Nguyen Thi Kim Loan kimloan.vnua@gmail.com  https://github.com/kimloan2911
Tran Thi Mai tranthimai233@gmail.com https://github.com/TranThiMAi683
Dang Van Loc locdangkvh892k@gmail.com https://github.com/locdang8
Ha Van Duyet havanduyet1998st@gmail.com https://github.com/Duyetzzz
Hoang The Vuong hoangthevuong.pb@gmail.com https://github.com/hoangthevuongvn
Nguyen Huy Duc huyduc7419@gmail.com https://github.com/huyduc74
Nguyen Nguyen Tu newlifeoftu92@gmail.com https://github.com/newlifeoftu
Vu Minh Tuan tuanvuminh1999@gmail.com  https://github.com/vuminhtuan2312
Le Duc Hoang Phuong phuongldh@gmail.com https://github.com/phuongldh86
Dinh Van Khoa dinhvankhoa14091999@gmail.com https://github.com/Khoa-Jocelyn
Quach Vu Khanh Linh nobilinhlinh@gmail.com https://github.com/QuachVuKhanhLinh
Bui Duc Hung bui6450@gmail.com https://github.com/Hung-Elsh
Le Thanh Long lethanhlong04012000@gmail.com https://github.com/Thanhlong2000998
Nguyen Duc Binh nb1998pro@gmail.com https://github.com/nguyenbinh1998
Phan Thanh Dong phanthanhdong311099@gmail.com https://github.com/dongpt311099
Ngo The Anh theanhngo2k@gmail.com https://github.com/Theanhngo2905
Pham Duy Thanh thanhphamduy2k@gmail.com https://github.com/duythanh2k
Nguyen Thi Lan Quynh quynhntl229@gmail.com https://github.com/ntlquynh2209
Luu Quang Huy huy97852@gmail.com https://github.com/huy97852
Nguyen Thi Nhung nguyenthinhung09052000@gmail.com https://github.com/NhungNTmin
Dao Duy Hung daoduyhung98@gmail.com https://github.com/blazewest
Nguyen Thi Minh Thuy minhthuy2814@gmail.com https://github.com/minhthuy145
Kieu Dang Khiem kdkhiem@gmail.com https://github.com/dangkhiem91
Truong Thi Tuoi truongphiet77@gmail.com https://github.com/tuoi1501
Duong Duc Quy quyduong251325@gmail.com https://github.com/quyduong141
Ngo Thanh Binh binhhp1702@gmail.com https://github.com/binh1702
Tong Duc Anh tongducanh2000@gmail.com https://github.com/tongducanh
Nguyen Duc Truong ndtruong.dev@gmail.com https://github.com/NDTruong-F
Tran Anh Quy tquy446@gmail.com https://github.com/AnhQuy123
Nguyen Ngoc Kim Cuong diamondnguyenkc@gmail.com https://github.com/diamondnguyenkc 
Le Duc Anh  leducanh2010vnnd@gmail.com https://github.com/lebeo2010vnnd
Nguyen Tuan Anh tuananh25102k@gmail.com https://github.com/nguyentuananh25102000
Ninh Duc Hieu duchieulp@gmail.com https://github.com/Hieu-Bom
Cao Dinh Trung caodinhtrung2k@gmail.com https://github.com/CaoTrungCa
Trinh Ngoc Hung ngochung207@gmail.com https://github.com/ngochung207
Ninh Van Chuong chuongnv.nd@gmail.com https://github.com/NinhVanChuong
Dinh Cong Hieu dinhconghieu.hy@gmail.com https://github.com/DINHCONGHIEU
Pham Thu Ha phamthuha0970@gmail.com  https://github.com/phamthuha0970
Do Trung Duc dotrungduc.it@gmail.com https://github.com/dotrungduc201291
Luu Quang Huy huylq25122000@gmail.com https://github.com/huylq2512
Le Anh Dung anhdung288.viindoo@gmail.com https://github.com/LeDungViindoo
Nguyen Duy Quyen duyquyencnt55@gmail.com https://github.com/duyquyen96 
Do Anh Dai doanhdai1997@gmail.com https://github.com/AnhDai1997
