Netherlands, 2024-09-03

Nova Code agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Bob Leers bob@novacode.nl https://github.com/bobslee

List of contributors:

Bob Leers bob@novacode.nl https://github.com/bobslee
