Curaçao, 2024-06-17

SMART Outsourcing & Business Consulting agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Stephen Anthony stephen@smart-obc.com https://github.com/smartobc-stephen

List of contributors:

Stephen Anthony stephen@smart-obc.com https://github.com/smartobc-stephen
Jeroen Gelderland jeroen@smart-obc.com  https://github.com/Jeroen-smart-obc
Alejandro Vyent alejandro@smartobc.com https://github.com/alejandro-vyent
