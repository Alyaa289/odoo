France, 2023-04-27

Le Filament agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Rémi Cazenave 30716308+remi-filament@users.noreply.github.com https://github.com/remi-filament

List of contributors:

Benjamin Rivier 35699580+benj-filament@users.noreply.github.com https://github.com/benj-filament
Juliana Poudou 35699320+JulianaPoudou@users.noreply.github.com https://github.com/JulianaPoudou
Mathieu Hazard 61692077+MathieuFilament@users.noreply.github.com https://github.com/MathieuFilament
Rémi Cazenave 30716308+remi-filament@users.noreply.github.com https://github.com/remi-filament
Théo Chapy 97020404+theo-le-filament@users.noreply.github.com https://github.com/theo-le-filament
