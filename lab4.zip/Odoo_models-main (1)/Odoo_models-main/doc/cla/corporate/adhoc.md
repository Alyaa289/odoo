Argentina, 08/06/2015

Adhoc agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Damián Soriano ds@adhoc.com.ar https://github.com/damiansoriano

List of contributors:

Damián Soriano ds@adhoc.com.ar https://github.com/damiansoriano
Juan José Scarafía jjs@adhoc.com.ar https://github.com/jjscarafia
Nicolás Mac Rouillon nmr@adhoc.com.ar https://github.com/nicomacr
Katherine Zaoral kz@adhoc.com.ar https://github.com/zaoral
Valentino Defelice vd@adhoc.com.ar https://github.com/ValentinoDefelice
Bruno Zanotti bz@adhoc.com.ar https://github.com/Bruno-Zanotti
Pablo Santiago Paez Sheridan pp@adhoc.com.ar https://github.com/PabloPaezSheridan
Juan Ignacio Carreras jc@adhoc.com.ar https://github.com/jcadhoc
Joel Zilli joz@adhoc.com.ar https://github.com/JoelZilli
Augusto Weiss awe@adhoc.com.ar https://github.com/augusto-weiss
Pablo Montenegro pam@adhoc.com.ar https://github.com/pablohmontenegro
Ignacio Cainelli ica@adhoc.com.ar https://github.com/ica-adhoc
Martin Diego Quinteros maq@adhoc.com.ar https://github.com/maq-adhoc
Maximiliano Mezzavilla mem@adhoc.com.ar https://github.com/mem-adhoc
Alexis Lopez loa@adhoc.com.ar https://github.com/ALopez-Adhoc
Rocio Marina Vega rov@adhoc.com.ar https://github.com/rov-adhoc
Camila Vives cav@adhoc.com.ar https://github.com/cav-adhoc
Celina Devigili ced@adhoc.com.ar https://github.com/ced-adhoc
Matías Velazquez mav@adhoc.com.ar https://github.com/mav-adhoc
Felipe García Suez feg@adhoc.com.ar https://github.com/feg-adhoc
Franco Leyes lef@adhoc.com.ar https://github.com/lef-adhoc
Julia Elizondo jue@adhoc.com.ar https://github.com/jue-adhoc
