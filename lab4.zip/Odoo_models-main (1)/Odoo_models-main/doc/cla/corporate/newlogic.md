Thailand, 2024-04-01

Newlogic Pte Ltd agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jérémy Bethmont jeremy@newlogic.com https://github.com/jerem

List of contributors:

Jérémy Bethmont jeremy@newlogic.com https://github.com/jerem
Baptiste baptiste@newlogic.com https://github.com/baptiste-n42
