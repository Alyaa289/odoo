Switzerland, 2015-11-09

brain-tec AG agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pascal Zenklusen pascal.zenklusen@braintec-group.com https://github.com/BT-pzenklusen

List of contributors:

Fréderic Garbely frederic.garbely@braintec-group.com https://github.com/BT-fgarbely
Kumar Aberer kumar.aberer@braintec-group.com https://github.com/BT-kaberer
Pascal Zenklusen pascal.zenklusen@braintec-group.com https://github.com/BT-pzenklusen
Nadal Francisco Garcia nadal.francisco@braintec-group.com https://github.com/BT-nfrancisco

