United Kingdom, 2023-02-11

Glo Networks Ltd agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Karl Southern karl@theangryangel.co.uk https://github.com/theangryangel

List of contributors:

Karl Southern karl@theangryangel.co.uk https://github.com/theangryangel
Karl Southern karl@glo.systems 