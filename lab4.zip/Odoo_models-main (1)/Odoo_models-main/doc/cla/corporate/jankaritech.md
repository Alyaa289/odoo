Nepal, 21.05.2019

JankariTech Pvt. Ltd. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Artur Neumann artur@jankaritech.com https://github.com/individual-it

List of contributors:

Artur Neumann artur@jankaritech.com https://github.com/individual-it

Phil Davis phil@jankaritech.com https://github.com/phil-davis

Paurakh Sharma Humagain paurakh011@gmail.com https://github.com/paurakhsharma

Saugat Pachhai suagatchhetri@outlook.com https://github.com/skshetry

Dipak Acharya dpakach@gmail.com https://github.com/dpakach
