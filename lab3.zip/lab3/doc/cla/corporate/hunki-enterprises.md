Netherlands, 2025-03-06

Hunki Enterprises BV agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Holger Brunn mail@hunki-enterprises.com https://github.com/hbrunn

List of contributors:

Holger Brunn mail@hunki-enterprises.com https://github.com/hbrunn
