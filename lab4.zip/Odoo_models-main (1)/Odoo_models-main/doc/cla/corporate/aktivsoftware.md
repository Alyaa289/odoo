India 2021-10-14

Aktiv Software Pvt. Ltd. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Aktiv Software odoo@aktivsoftware.com https://github.com/odooaktiv/odoo

List of contributors:

Aktiv Software odoo@aktivsoftware.com https://github.com/odooaktiv/odoo
