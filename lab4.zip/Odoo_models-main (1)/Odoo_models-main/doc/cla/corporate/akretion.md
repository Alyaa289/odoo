Brazil, France, 2015-04-14

Akretion France agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Sébastien BEAU sebastien.beau@akretion.com https://github.com/akretion


Akretion LTDA agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,
Raphaël Valyi raphael.valyi@akretion.com https://github.com/akretion


List of contributors:

Abdessamad Hilali abdessamad.hilali@akretion.com https://github.com/ahilali
Adrien Chaussende adrien.chaussende@akretion.com https://github.com/achaussende
Alexis de Lattre alexis.delattre@akretion.com https://github.com/alexis-via
Arthur Vuillard arthur.vuillard@akretion.com https://github.com/arthru
Benoît Guillot benoit.guillot@akretion.com https://github.com/bguillot
Chafique delli chafique.delli@akretion.com https://github.com/chafique-delli
Cilene Oliveira cilene.oliveira@akretion.com https://github.com/cileneoliveira
Clément Mombereau clement.mombereau@akretion.com.br https://github.com/clementmbr
David Beal david.beal@akretion.com https://github.com/bealdav
Florian da Costa florian.dacosta@akretion.com https://github.com/florian-dacosta
Magno Barcelo da Costa magno.costa@akretion.com.br https://github.com/mbcosta
Mourad El Hadj Mimoune mourad.elhadj.mimoune@akretion.com https://github.com/mourad-ehm
Pierrick Brun pierrick.brun@akretion.com https://github.com/PierrickBrun
Raphaël Reverdy raphael.reverdy@akretion.com https://github.com/hparfr
Raphaël Valyi raphael.valyi@akretion.com https://github.com/rvalyi
Renato Lima renato.lima@akretion.com https://github.com/renatonlima
Sebastien Beau sebastien.beau@akretion.com https://github.com/sebastienbeau
Sylvain Calador sylvain.calador@akretion.com https://github.com/sylvainc
Sylvain Legal sylvain.legal@akretion.com https://github.com/legalsylvain
Thiago Moreira de Souza Arrais thiago.moreira@akretion.com.br https://github.com/thiagomds
Valentin Chemiere valentin.chemiere@akretion.com https://github.com/viggor
Vianney da Costa vianney.dacosta@akretion.com.br https://launchpad.net/~vianneydc
