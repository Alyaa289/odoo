China, 2022-04-05

Medoo Tech agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

jlzhou zh@medoo.tech https://github.com/jlzhou

List of contributors:

jlzhou zh@medoo.tech https://github.com/jlzhou
