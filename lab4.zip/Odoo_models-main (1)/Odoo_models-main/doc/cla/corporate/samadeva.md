France, 2024-07-17

SAS Ermitage agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Samadeva admin.odoo@samadeva.com https://github.com/Samadeva