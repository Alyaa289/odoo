South Africa, 2022-01-10

SystemWorks agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Michael de Villiers michael@systemworks.co.za https://github.com/COUR4G3

List of contributors:

Michael de Villiers michael@systemworks.co.za https://github.com/COUR4G3
Mziwakhe Ndinga mzi@systemworks.co.za https://github.com/mndinga
Alex Zimmerman alexz@systemworks.co.za https://github.com/AFZimmers

