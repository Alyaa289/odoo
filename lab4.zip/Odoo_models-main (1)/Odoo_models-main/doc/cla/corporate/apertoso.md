Belgium, 2015-02-13

Apertoso agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jos De Graeve Jos.DeGraeve@apertoso.be https://github.com/apertoso

List of contributors:

Jos De Graeve Jos.DeGraeve@apertoso.be https://github.com/JosDeGraeve
Maarten De Wispelaere Maarten.DeWispelaere@apertoso.be https://github.com/bitprocessor
Jean-Paul Robineau Jean-Paul.Robineau@apertoso.be https://github.com/jeanpaulrobineau
