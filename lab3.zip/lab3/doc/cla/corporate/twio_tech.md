Switzerland, 2023-04-11

twio.tech AG agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sandro Faeh hello@twio.tech https://github.com/twio-tech

List of contributors:

Dawn Hwang hwangh95@gmail.com https://github.com/hwangh95
