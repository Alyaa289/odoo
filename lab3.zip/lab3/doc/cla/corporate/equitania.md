Germany, 2017-09-11

Equitania Software GmbH agrees to the terms of the
Odoo  Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Martin Schmid m.schmid@equitania.com https://github.com/eqms

List of contributors:

Julia Eberle j.eberle@equitania.de https://github.com/eqje
Paul Exler p.exler@equitania.de https://github.com/eqpe
Oliver Hercht o.hercht@equitania.de https://github.com/eqoh
Johann Müller j.mueller@equitania.de https://github.com/eqjm
Robin Prijatel r.prijatel@equitania.de https://github.com/eqrp
Michal Sodomka m.sodomka@equitania.de https://github.com/eqmiso

