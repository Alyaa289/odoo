Vietnam, 2016-09-19

Trobz agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Denis Barbot dbarbot@trobz.com https://github.com/dbarbot

List of contributors:

Denis Barbot dbarbot@trobz.com https://github.com/dbarbot
Jean-Charles Drubay jcdrubay@trobz.com https://github.com/jcdrubay
Bui Ngoc Tu tu@trobz.com https://github.com/tungocbui
Diep Huu Hoang hoang@trobz.com https://github.com/anothingguy
