Spain, 2017-03-21

Eficent Business and IT Consulting Services, S.L. agrees to the terms of the
Odoo  Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jordi Ballester jordi.ballester@eficent.com https://github.com/jbeficent

List of contributors:

Aarón Henríquez ahenriquez@eficent.com https://github.com/aheficent
Lois Rilo lois.rilo@eficent.com https://github.com/lreficent
Miquel Raich miquel.raich@eficent.com https://github.com/mreficent
Jordi Ballester jordi.ballester@eficent.com https://github.com/jbeficent
Hector Villarreal hector.villarreal@eficent.com https://github.com/hveficent

NOTE: As of Dec 11th 2019, Eficent is rebranded to ForgeFlow, thus this CLA is
only valid until that date, refer to forgeflow.md for the new CLA.
