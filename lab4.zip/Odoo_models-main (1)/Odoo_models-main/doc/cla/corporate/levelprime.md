Italy, 2017-04-18

Level Prime Srl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Roberto Fichera roberto.fichera@levelprime.com https://github.com/robyf70
Filippo Iovine - filippo.iovine@levelprime.com - https://github.com/FilippoIOVINE


List of contributors:

Roberto Fichera roberto.fichera@levelprime.com https://github.com/robyf70
Roberto Fichera robyf@tekno-soft.it https://github.com/robyf70
Filippo Iovine - filippo.iovine@levelprime.com - https://github.com/FilippoIOVINE
Filippo Iovine - filippo.jovine@gmail.com - https://github.com/FilippoIOVINE
