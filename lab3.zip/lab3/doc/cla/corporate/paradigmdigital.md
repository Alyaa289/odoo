South Africa, 2018-08-20

Paradigm Digital (Pty) Ltd agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Habib Ayob habib@paradigmdigital.co.za https://github.com/paradigmdigital

List of contributors:

Habib Ayob habib@paradigmdigital.co.za https://github.com/h4818
