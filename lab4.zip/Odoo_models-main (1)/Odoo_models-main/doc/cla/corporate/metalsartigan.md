Canada, 2017-3-24

Métal Sartigan agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jérôme Thériault jerther@gmail.com https://github.com/jerther

List of contributors:

Jérôme Thériault jerther@gmail.com https://github.com/jerther
