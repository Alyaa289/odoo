France, 2018-06-20

JANUS agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Martin Duvergey martin.duvergey@gpsante.fr https://github.com/mduvergey

List of contributors:

Martin Duvergey martin.duvergey@gpsante.fr https://github.com/mduvergey
