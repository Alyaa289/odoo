France, 2018-11-14

Subteno IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sébastien LANGE sla@subteno.com https://github.com/sla-subteno-it

List of contributors:

Sébastien LANGE sla@subteno-it.com https://github.com/sla-subteno-it
Christian LECOUFLE christian.lecoufle@subteno-it.fr https://github.com/cle-subteno-it
Vincent COFFIN vincent.coffin@subteno-it.fr https://github.com/vco-subteno-it
Jeremy CORMIER jeremy.cormier@subteno-it.fr https://github.com/jco-subteno-it
Christian LECOUFLE cle@subteno.com https://github.com/cle-subteno-it
Vincent COFFIN vco@subteno.com https://github.com/vco-subteno-it
Jeremy CORMIER jco@subteno.com https://github.com/jco-subteno-it