Denmark, 2020-09-14

VK DATA ApS agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Visti Kristensen visti@vkdata.dk https://github.com/visti-vkd

List of contributors:

Kenneth Hansen kenneth@vkdata.dk https://github.com/kenneth-vkd
Simon Andersen simon@vkdata.dk https://github.com/simon-vkd
Mads Søndergaard mads@vkdata.dk https://github.com/mads-vkd
Jacob Sørensen jacob@vkdata.dk https://github.com/jacob-vkd
Kristian Sørensen kristian@vkdata.dk https://github.com/kristian-vkd