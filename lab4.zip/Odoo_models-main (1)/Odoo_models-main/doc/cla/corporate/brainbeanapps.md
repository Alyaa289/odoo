Estonia, 23 OCT 2018

Brainbean Apps OU agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Oleksii Pelykh <alexey@brainbeanapps.com> https://github.com/alexey-pelykh

List of contributors:

Alexey Pelykh <alexey@brainbeanapps.com> https://github.com/alexey-pelykh
