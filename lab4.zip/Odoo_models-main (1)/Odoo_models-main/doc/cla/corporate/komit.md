Vietnam, 2019-08-23

KOMIT CO.,LTD agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jean-Charles DRUBAY jc@komit-consulting.com https://github.com/jcdrubay

List of contributors:

Cuong NGUYEN MINH TRAN MANH cuong.nmtm@komit-consulting.com https://github.com/cuongnmtm
Duc TRUONG DINH MINH duc.tdm@komit-consulting.com https://github.com/DucTruongKomit
Hieu VO MINH BAO hieu.vmb@komit-consulting.com https://github.com/hieulucky111
Jean-Charles DRUBAY jc@komit-consulting.com https://github.com/jcdrubay
QUOC PHAM NGOC quoc-pn@komit-consulting.com https://github.com/quoc-pn
