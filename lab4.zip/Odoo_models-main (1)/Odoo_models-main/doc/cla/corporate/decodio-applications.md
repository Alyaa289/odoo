Croatia, 2019-03-05

Decodio Applications d.o.o. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Goran Kliska gkliska@gmail.com https://github.com/decodio-applications

List of contributors:

Goran Kliska goran.kliska@decod.io https://github.com/gkliska
Ivan Vađić ivan.vadjic@decod.io https://github.com/IvanVadjic
Dario Meniss dario.meniss@decod.io https://github.com/dariomeniss
Marko Falatec marko.falatec@decod.io https://github.com/mfalatec
Ana-Maria Olujić ana-maria.olujic@decod.io https://github.com/anamaria2208992
Davor Bojkić davor.bojkic@decod.io https://github.com/badbole
