Ireland, 2015-06-26

Syncordia Technologies and Healthcare Solutions Ireland Limited agrees to the terms of the 
Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Vadim Zenin vadim.zenin@syncordiahealth.ie https://github.com/Vadim-Zenin

List of contributors:

Vadim Zenin vadim.zenin@syncordiahealth.ie https://github.com/Vadim-Zenin
Vadims Briksins vadim.bryksin@syncordiahealth.ie https://github.com/Briksins
