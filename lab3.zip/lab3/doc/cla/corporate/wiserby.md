Estonia, 2020-04-17

Wiserby OÜ agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Wiserby info@wiserby.com https://github.com/Wiserby

List of contributors:

Denis Zhadan denis@sparksoft.eu https://github.com/DenisZhadan
Wiserby info@wiserby.com https://github.com/Wiserby
