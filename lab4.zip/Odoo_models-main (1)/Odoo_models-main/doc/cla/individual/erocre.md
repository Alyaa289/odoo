Spain, 2016-04-08

I hereby agree to the terms of the Odoo Individual Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Eduardo Rodriguez erocre@gmail.com https://github.com/erocre
