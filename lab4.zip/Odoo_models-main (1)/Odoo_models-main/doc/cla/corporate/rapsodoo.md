Rome, 2021-01-13

Rapsodoo agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Filippo Iovine filippo.iovine@rapsodoo.com https://github.com/ioFilippo

List of contributors:

Filippo Iovine filippo.iovine@rapsodoo.com https://github.com/ioFilippo
Lucio Valente lucio.valente@rapsodoo.com https://github.com/luciovalente
Mario Pitingolo mario.pitingolo@rapsodoo.com https://github.com/Pits79
Simone Papandrea simone.papandrea@rapsodoo.com https://github.com/SI3P
Davide Fella davide.fella@rapsodoo.com https://github.com/davidefella
Angel Corpuz angel.corpuz@rapsodoo.com https://github.com/acorpuz
Tony Masci tony.masci@rapsodoo.com https://github.com/TonyMasciI
Andrea Patusso andrea.patusso@rapsodoo.com https://github.com/AndreaPatusso
Valentina Maltese valentina.maltese@rapsodoo.com https://github.com/ValentinaMal
Tommaso Bellelli tommaso.bellelli@rapsodoo.com https://github.com/tommasobellelli
Saydigital info@rapsodoo.com https://github.com/saydigital
Valerio Belcastro valerio.belcastro@rapsodoo.com https://github.com/valeriobelcastro
