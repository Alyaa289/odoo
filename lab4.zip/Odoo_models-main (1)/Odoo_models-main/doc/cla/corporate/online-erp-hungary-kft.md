Hungary, 2021-02-24

Online ERP Hungary Kft. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Csaba Tóth csaba.toth@online-erp.hu https://github.com/tsabi

List of contributors:

Csaba Tóth csaba.toth@online-erp.hu https://github.com/tsabi
Attila Eiler eiler.attila@online-erp.hu https://github.com/Eilerant
András Horváth horvath.andras@online-erp.hu https://github.com/siriusandris
Miklós Zsitva zsitva.miklos@online-erp.hu https://github.com/nurefexc
László Balassa balassa.laszlo@online-erp.hu https://github.com/BLacika
Zsolt Godó godo.zsolt@online-erp.hu https://github.com/sakaitsu
Ákos Lőrincz lorincz.akos@online-erp.hu https://github.com/LorinczAks
Balázs Regényi regenyi.balazs@online-erp.hu https://github.com/regisz
