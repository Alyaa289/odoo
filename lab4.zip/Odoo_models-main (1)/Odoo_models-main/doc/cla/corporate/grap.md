France, May 22, 2016

GRAP agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sylvain LE GAL sylvain.legal@grap.coop https://github.com/legalsylvain
Quentin DUPONT quentin.dupont@grap.coop https://github.com/quentinDupont

List of contributors:

Sylvain LE GAL sylvain.legal@grap.coop https://github.com/legalsylvain
Quentin DUPONT quentin.dupont@grap.coop https://github.com/quentinDupont
