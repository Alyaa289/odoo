Saudi Arabia, April 24, 2016

Cloudland agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Fahad Alqahtani alqfahad@gmail.com https://github.com/alqfahad

List of contributors:

Fahad Alqahtani alqfahad@gmail.com https://github.com/alqfahad
