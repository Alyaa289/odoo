United Kingdom, 2015-06-12

Credativ Limited agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Irenie White irenie.white@credativ.co.uk

List of contributors:

Craig Gowing    craig.gowing@credativ.co.uk     https://github.com/craiggowing
David Spautz    david.spautz@credativ.co.uk     https://github.com/dspautz
Jacob Hicks     jacob.hicks@credativ.co.uk      https://github.com/JaHicks
Ondřej Kuzník   ondrej.kuznik@credativ.co.uk    https://github.com/mistotebe
Kinner Vachhani kinner.vachhani@credativ.co.uk  https://github.com/kenvac
Tom Pickering   tom.pickering@credativ.co.uk    https://github.com/tompickering
