Switzerland, Italy, 2022-08-26

Agile Business Group Sagl and Agile Business Group Italia Srl agree to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Stefano Sforzi stefano.sforzi@agilebg.com https://github.com/agilebg

List of contributors:

Alex Comba alex.comba@agilebg.com https://github.com/tafaRU
Alberto Re alberto.re@agilebg.com https://github.com/are-agilebg
Michele Rusticucci michele.rusticucci@agilebg.com https://github.com/michelerusti
