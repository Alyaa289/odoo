Spain, 2018-05-12

Acysos S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Ignacio Ibeas ignacio@acysos.com https://github.com/acysos

List of contributors:

Ignacio Ibeas info@acysos.com https://github.com/acysos
Ignacio Ibeas ignacio@acysos.com https://github.com/acysos
Alex Ezquebo alexander@acysos.com https://github.com/acysos
Leonidas Pezo leonidas@acysos.com https://github.com/acysos
