France, 2016-05-18

iRaiser agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Bruno PLANCHER bplancher@iraiser.eu https://github.com/bplancher

List of contributors:

Bruno PLANCHER bplancher@iraiser.eu https://github.com/bplancher
Damien NICOLAS dnicolas@iraiser.eu https://github.com/gordonzola

