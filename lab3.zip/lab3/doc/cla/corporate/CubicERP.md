Lima, Peru, 2015-04-01

Cubic ERP S.A.C. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Cubic ERP S.A.C. info@cubicerp.com https://github.com/CubicERP

List of contributors:

Yury Oscar Tello Canchapoma ytello@cubicerp.com https://github.com/yurytello
Virginia De la Cruz Sinchez vdelacruz@cubicerp.com https://github.com/virginiamaura
Lisbeth Gutierrez Masa lgutierrez@cubicerp.com https://github.com/lisbethgutierrez
