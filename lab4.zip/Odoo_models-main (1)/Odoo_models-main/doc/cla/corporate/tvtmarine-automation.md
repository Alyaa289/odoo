Vietnam, 2017-04-03

T.V.T Marine Automation agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

David Tran david.tran@tvtmarine.com https://github.com/tvtma/

List of contributors:

David Tran david.tran@tvtmarine.com https://github.com/davidtranhp
Phong Dao phong.dao@tvtmarine.com https://github.com/phongdao
Hao Hoang hao.hoang@ma.tvtmarine.com https://github.com/hoanghao2001
Tommy Tran tu.tran@tvtmarine.com https://github.com/tutran81
Trinh Anh Ngoc ngoc.trinh@tvtmarine.com https://github.com/trinhanhngoc
Bui Hoang Ha habh.hpit@gmail.com https://github.com/hoanghavb

(up to 2019-07-14)
Long Do long.do@tvtmarine.com https://github.com/hoanglong87