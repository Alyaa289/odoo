Spain, 2015-04-20

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Vicent Cubells vicent@vcubells.net https://github.com/cubells
