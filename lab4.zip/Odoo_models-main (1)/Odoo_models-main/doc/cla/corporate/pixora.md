Catania, 2023-06-12

Pixora Srl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Salvatore Davide Rapisarda sdrapisarda@gmail.com https://github.com/salvorapi

List of contributors:

Salvatore Davide Rapisarda sdrapisarda@gmail.com https://github.com/salvorapi <br />
Igor Di Mauro igorisher3@gmail.com https://github.com/dimaurosalvatore <br />
Alejandro Genesio angenesio@gmail.com https://github.com/AlejandroGenesio <br />
