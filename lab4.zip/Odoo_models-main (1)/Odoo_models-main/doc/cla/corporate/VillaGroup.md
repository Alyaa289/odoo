México, 2024-06-28

Villa Group agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Diego Pelayo diego.pelayo@villagroup.com https://github.com/DiegoVGV

List of contributors:

Diego Pelayo diego.pelayo@villagroup.com https://github.com/DiegoVGV
