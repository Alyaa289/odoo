Italy, 2015-11-05

Abstract Srl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Davide Corio davide.corio@abstract.it https://github.com/dcorio


List of contributors:

Davide Corio davide.corio@abstract.it https://github.com/dcorio
Simone Orsi simone.orsi@abstract.it https://github.com/simahawk
Giacomo Spettoli giacomo.spettoli@abstract.it https://github.com/giacomos 
