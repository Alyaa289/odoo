Lithuania, 2018-12-12

Focusate JSC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Andrius Laukavičius andrius@focusate.eu https://github.com/oerp-odoo

List of contributors:

Andrius Laukavičius andrius@focusate.eu https://github.com/oerp-odoo
