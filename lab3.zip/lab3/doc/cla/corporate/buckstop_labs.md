USA, 2024-02-20

Buckstop Labs, LLC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Mark F. Young mark.francis.young@gmail.com https://github.com/markfyoung0711

List of contributors:

Mark F. Young mark.francis.young@gmail.com https://github.com/markfyoung0711
