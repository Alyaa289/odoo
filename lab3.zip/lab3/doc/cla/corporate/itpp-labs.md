Russia, 2021-03-20

IT Projects Labs agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Denis Mudarisov denis.mudarisov@gmail.com https://github.com/trojikman

List of contributors:

Denis Mudarisov denis.mudarisov@gmail.com https://github.com/trojikman
