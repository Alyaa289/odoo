Italy, 2016-02-23

Telnet Servizi Srl agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Telnet Data github@telnetservizi.it https://github.com/telnetdata

List of contributors:

Telnet Data github@telnetservizi.it https://github.com/telnetdata
Matteo Cantarutti cantarutti.matteo@live.it https://github.com/mteok
