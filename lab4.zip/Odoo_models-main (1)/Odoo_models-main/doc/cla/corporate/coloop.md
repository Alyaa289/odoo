United Kingdom, 2020-07-21

Coloop Ltd. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Alex Hafner alex.hafner@coloop.com https://github.com/alexhafner

List of contributors:

Alex Hafner alex.hafner@coloop.com https://github.com/alexhafner
Herbert Riess herbert.riess@coloop.com https://github.com/r13ssh