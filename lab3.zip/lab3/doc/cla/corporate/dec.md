France, 2021-07-01

DEC agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

DEC github@decgroupe.com https://github.com/decgroupe

List of contributors:

Yann Papouin ypa@decgroupe.com https://github.com/ypapouin
