Germany, 2022-04-28

manaTec GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Robert Duckstein robert.duckstein@manatec.de https://github.com/rd-manatec

List of contributors:

Tobias Reinwarth mailtobyte@googlemail.com https://github.com/tobytes

Tom Tietze tietze.development@web.de https://github.com/TomTietze

Philipp Köhler bandsache@gmx.net https://github.com/fploetzlich

Alexander Heyber alexander.heyber@manatec.de https://github.com/alexander-heyber-manatec

Walter Salzmann walter.salzmann@manatec.de https://github.com/ws-manatec

Gerald Malsch gerald.malsch@manatec.de https://github.com/AlienAtSystem
