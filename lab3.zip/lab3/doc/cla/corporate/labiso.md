Germany, 2025-02-07

LABISO GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Laurence Lars Labusch lala@labiso.de https://github.com/llabusch93

List of contributors:

Laurence Lars Labusch lala@labiso.de https://github.com/llabusch93
Anh Vu Nguyen vung@labiso.de https://github.com/vung-labiso
