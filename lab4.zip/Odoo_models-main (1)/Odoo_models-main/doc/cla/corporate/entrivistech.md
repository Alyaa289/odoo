India, 2021-04-21

Entrivis Tech Private Limited agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Entrivis Tech Pvt. Ltd. hello@entrivistech.com https://github.com/Entrivis-Tech

List of contributors:

Krutarth Buch krutarth@entrivistech.com https://github.com/krutarthbuch
Meet Dholakia meet@entrivistech.com https://github.com/MeetKD
