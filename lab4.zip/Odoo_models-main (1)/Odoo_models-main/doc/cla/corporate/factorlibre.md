Spain, 2020-07-14

Factor Libre S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Daniel Duque daniel.duque@factorlibre.com https://github.com/danielduqma

List of contributors:

Daniel Duque daniel.duque@factorlibre.com https://github.com/danielduqma
Hugo Santos hugo.santos@factorlibre.com https://github.com/hugosantosred
Jorge Martínez jorge.martinez@factorlibre.com https://github.com/jorgemartinez-factorlibre
Adriana Saiz adriana.saiz@factorlibre.com https://github.com/AdrianaSaiz
Pablo Calvo pablo.calvo@factorlibre.com https://github.com/Pablocce
Juan Carlos Bonilla juancarlos.bonilla@factorlibre.com https://github.com/suker
Adrián Cifuentes adrian.cifuentes@factorlibre.com https://github.com/xadriancif
Miguel Cepeda miguel.cepeda@factorlibre.com https://github.com/miguelcb2003