Lithuania, 2020-08-24

Via laurea agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Gailius Kazlauskas gailius.kaz@vialaurea.lt https://github.com/gaikaz

List of contributors:

Gailius Kazlauskas gailius.kaz@vialaurea.lt https://github.com/gaikaz
Donatas Valiulis donatas@vialaurea.lt https://github.com/DonatasV
Domantas Girdžiūnas domantas@vialaurea.lt https://github.com/Du-ma
Mantas Šniukas mantas@vialaurea.lt (up to 2024-09-13)
Saulius Zilys saulius@vialaurea.lt (up to 2017-04-24)
