Belgium, 2022-10-26

Coop IT Easy SC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Carmen Bianca Bakker <carmen@coopiteasy.be> https://github.com/carmenbianca

List of contributors:

Carmen Bianca Bakker <carmen@coopiteasy.be> https://github.com/carmenbianca

Catherine Lembrée <catherine@coopiteasy.be> https://github.com/cathLemb

Hugues De Keyzer <odoo@hugues.info> https://github.com/huguesdk

Pol Champion <pol@coopiteasy.be> https://github.com/polchampion

Rémy Taymans <remytms@tsmail.eu> https://github.com/remytms

Robin Keunen <robin@keunen.net> https://github.com/robinkeunen

Victor Champonnois <victor@coopiteasy.be> https://github.com/victor-champonnois

Virginie Dewulf <virginie@coopiteasy.be> https://github.com/vdewulf

