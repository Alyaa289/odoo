from . import patient
from . import department
from . import doctors
from . import patient_log
from . import res_partner
