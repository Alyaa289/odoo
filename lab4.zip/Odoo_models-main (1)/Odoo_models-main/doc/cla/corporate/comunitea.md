Spain, 2022-08-12

Comunitea Servicios Tecnológicos S.L.
agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Omar Castiñeira Saavedra omar@comunitea.com https://github.com/omar7r

List of contributors:

Omar Castiñeira Saavedra omar@comunitea.com https://github.com/omar7r
Javier Colmenero Fernández javier@comunitea.com https://github.com/javierjcf
Francisco José Sánchez Álvarez kiko@comunitea.com https://github.com/kikosanchez
Santiago Argüeso Armesto santi@comunitea.com https://github.com/Roodin
Vicente Gutiérrez Fernández vicente@comunitea.com https://github.com/vicentecom
