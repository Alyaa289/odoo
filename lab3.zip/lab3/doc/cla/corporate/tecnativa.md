Spain, 2017-04-04

Tecnativa S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pedro M. Baeza pedro.baeza@tecnativa.com https://github.com/pedrobaeza

List of contributors:

Pedro M. Baeza pedro.baeza@tecnativa.com https://github.com/pedrobaeza
Rafael Blasco rafael.blasco@tecnativa.com https://github.com/rafaelbn (up to 2020-01-01)
Sergio Teruel sergio.teruel@tecnativa.com https://github.com/sergio-teruel
Carlos Dauden carlos.dauden@tecnativa.com https://github.com/carlosdauden
Jairo Llopis jairo.llopis@tecnativa.com https://github.com/yajo (up to 2021-11-25)
David Vidal david.vidal@tecnativa.com https://github.com/chienandalu (up to 2025-03-31)
Cristina Martín cristina.martin@tecnativa.com https://github.com/cristinamartinrod (up to 2019-04-30)
Ernesto Tejeda ernesto.tejeda@tecnativa.com https://github.com/ernestotejeda (up to 2023-06-30)
Alexandre Díaz alexandre.diaz@tecnativa.com https://github.com/Tardo (up to 2022-08-31)
Víctor Martínez victor.martinez@tecnativa.com https://github.com/victoralmau
João Marques joao.marques@tecnativa.com https://github.com/joao-p-marques
Carlos Roca carlos.roca@tecnativa.com https://github.com/CarlosRoca13
Pilar Vargas pilar.vargas@tecnativa.com https://github.com/pilarvargas-tecnativa
Carolina Fernández carolina.fernandez@tecnativa.com https://github.com/carolinafernandez-tecnativa
Josep Guardiola josep.guardiola@tecnativa.com https://github.com/josep-tecnativa
