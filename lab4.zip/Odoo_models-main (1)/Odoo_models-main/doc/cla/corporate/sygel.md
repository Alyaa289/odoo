Spain, 2020-05-19

Sygel Technology S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Harald Panten harald.panten@sygel.es https://github.com/HaraldPanten

List of contributors:

Harald Panten harald.panten@sygel.es https://github.com/HaraldPanten
Valentín Vinagre valentin.vinagre@sygel.es https://github.com/ValentinVinagre
Manuel Regidor manuel.regidor@sygel.es https://github.com/manuelregidor
Alberto Martínez alberto.martinez@sygel.es https://github.com/tisho99
