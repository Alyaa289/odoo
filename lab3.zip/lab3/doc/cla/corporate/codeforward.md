Netherlands, 2024-10-16

Codeforward B.V. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Sander Lienaerts sander.lienaerts@codeforward.nl https://github.com/sanderlienaerts

List of contributors:

Chris Bergman chris.bergman@codeforward.nl https://github.com/chrisb-c01 
Joep Sanders joep.sanders@codeforward.nl https://github.com/joepsanders 
Lars Quaedvlieg lars.quaedvlieg@codeforward.nl https://github.com/Larsq1 
Sander Lienaerts sander.lienaerts@codeforward.nl https://github.com/sanderlienaerts
