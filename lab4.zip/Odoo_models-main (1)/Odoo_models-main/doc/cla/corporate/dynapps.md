Belgium, 2015-06-04

DynApps N.V. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Raf Ven raf.ven@dynapps.be https://github.com/rven

List of contributors:

Raf Ven raf.ven@dynapps.be https://github.com/rven
Kurt Schmitz kurt.schmitz@dynapps.be https://github.com/kurt-schmitz
Rod Schouteden rod.schouteden@dynapps.be https://github.com/schout-it
Eric Lembregts eric.lembregts@dynapps.be https://github.com/lembregtse
Pieter Paulussen pieter.paulussen@dynapps.be https://github.com/PieterPaulussen (up to 2019-10-01)
Bart Van Bossche bart.vanbossche@dynapps.be https://github.com/bartvanbossche-dynapps
