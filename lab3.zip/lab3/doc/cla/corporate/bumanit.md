Mongolia, 2019-06-14

BumanIT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Baskhuu Lodoikhuu baskhuujacara@gmail.com https://github.com/jacara
Baskhuu Lodoikhuu baskhuu@bumanit.mn https://github.com/bumanit

List of contributors:

Baskhuu Lodoikhuu baskhuujacara@gmail.com https://github.com/jacara
Baskhuu Lodoikhuu baskhuu@bumanit.mn https://github.com/bumanit
