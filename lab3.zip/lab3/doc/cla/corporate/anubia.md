Spain, 2015-04-15

Anubía, soluciones en la nube,SL
agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Alejandro Santana alejandrosantana@anubia.es https://github.com/alejandrosantana

List of contributors:

Alejandro Santana alejandrosantana@anubia.es https://github.com/alejandrosantana
Juan Formoso Vasco jfv@anubia.es https://github.com/forvas
Jesús Cacabelos Reyes jrc@anubia.es https://github.com/chesucr
Eduardo Rodríguez Crespo erc@anubia.es https://github.com/erc-anubia
Jorge Soto García jsg@anubia.es https://github.com/sotogarcia
Daniel Lago Suárez dls@anubia.es https://github.com/dlsuarez
