Belgium, 2022-11-03

Aerospacelab S.A. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Thibault Libioulle thibault.libioulle@aerospacelab.be https://github.com/tli-asl

List of contributors:

Thibault Libioulle thibault.libioulle@aerospacelab.be https://github.com/tli-asl
Rémi Chauvenne remi.chauvenne@aerospacelab.be https://github.com/rch-asl
