Belgium, 2020-01-11

CodeSource agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Pieter Paulussen pieterpaulussen@code-source.be https://github.com/PieterPaulussen

List of contributors:

Pieter Paulussen pieterpaulussen@code-source.be https://github.com/PieterPaulussen
