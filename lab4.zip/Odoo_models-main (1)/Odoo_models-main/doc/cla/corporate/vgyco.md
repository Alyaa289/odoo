México, 2024-02-29

Consultoría VG & Compañia agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Cesar Yoab Villarreal cyoab@vgyco.com https://github.com/cyoab

List of contributors:

Cesar Yoab Villarreal cyoab@vgyco.com https://github.com/cyoab