Venezuela, 2024-05-25

Binaural agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Binaural C.A., contacto@binauraldev.com https://github.com/binaural-dev

List of contributors:

Anderson Armeya anderson@binauraldev.com https://github.com/andyengh
Miguel Gozaine miguel@binauraldev.com https://github.com/miguel-binaural
Yeison Asuaje yeison@binauraldev.com https://github.com/Yeisonasuaje
Christopher Gomez Dallar christopher@binauraldev.com https://github.com/christopherBinaural
Bryan García bryan@binauraldev.com https://github.com/bryanbinaural
Carlos Linarez carlos@binauraldev.com https://github.com/Carlos-Lin-Binaural
Ana Calles ana@binauraldev.com https://github.com/binapaulina
Manuel Guerrero manuel.guerrero@binauraldev.com https://github.com/manuelgc1201
